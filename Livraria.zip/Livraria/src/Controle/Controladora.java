package Controle;

import Apresentacao.TelaPrincipal;

/**
 *
 * @author Juliana
 */
public class Controladora {
    TelaPrincipal obj_telaPrincipal;
    public void mostrarTela(){
        this.obj_telaPrincipal = new TelaPrincipal ();
        obj_telaPrincipal.setVisible(true);
}
}
